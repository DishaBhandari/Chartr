<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterUserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [App\Http\Controllers\HomeController::class, 'index']);

Route::get('/register-user', [RegisterUserController::class, 'registerView']);
Route::post('/registerSubmit', [RegisterUserController::class, 'store'])->name('reg_form');
Route::get('/register-list-view', [RegisterUserController::class, 'listView']);

//Fetch City
Route::post('fetch_cities', [RegisterUserController::class, 'fetchCities']);


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::post('/store', [RegisterUserController::class, 'store'])->name('store');

Route::get('/view_ticket', [RegisterUserController::class, 'viewTicket'])->name('view_ticket');


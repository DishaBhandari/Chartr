        
        <footer class="footer text-center text-sm-left">
            &copy; <?php echo e(date('Y')); ?> <a href=""><?php echo e(env('APP_NAME')); ?></a>
        </footer><!--end footer-->
    </div><!-- end page content -->
</div>

        <!-- jQuery  -->
        <script src="<?php echo e(asset('/theme/default/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/metismenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/feather.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/moment.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/plugins/daterangepicker/daterangepicker.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('/theme/default/assets/js/app.js')); ?>"></script>
        
        
    </body>
</html><?php /**PATH D:\PSSPL Project\Chartr\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
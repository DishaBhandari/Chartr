<?php $__env->startSection('content'); ?>

  <div class="container-scroller" style="margin-top: -30px;">
      <div class="logo mx-auto">
        <div class="container text-center d-flex justify-content-center mt-3">
          <div class="col-5 col-md-3">
            <img src="https://prakhardemos.com/ddu_gky/images/prakhar_logo.png" class="img-fluid" style="max-height: 110px;" alt="logo">
          </div>
          
        </div>
      </div>
    <div class="container-fluid py-0">
      <center>
      <div class="col-10 col-sm-8 col-md-4 auth pt-1">
        
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="w-100 mb-5">
                <h3 style="font-weight:bold;color:green">Prakhar Software Solutions Pvt. Ltd.</h3>
                 
              </div>
              <div class="row">  
                <?php if(session('alert_status')): ?>
                    <h6 class="alert alert-success"><?php echo e(session('alert_status')); ?></h6>
                <?php endif; ?>      
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
                    <?php endif; ?>
            </div>
              <h4>Hello! let's get started</h4>
              <h6 class="fw-normal">Sign in to continue.</h6>
              <form method="POST" action="<?php echo e(route('login')); ?>" class="pt-3">
                  <?php echo csrf_field(); ?>
                <div class="form-group">
                 <input id="user_code" type="text" class="form-control form-control-lg <?php $__errorArgs = ['user_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('user_code')); ?>" required autocomplete="user_code" autofocus  placeholder="Username">

                  
                </div>
                <div class="form-group position-relative mt-3">
                  <i class="fa fa-eye show_hide_pass" aria-hidden="true" style="position:absolute; right:10px; top:16px; font-size: 19px; z-index:1000"></i>
                  <input type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" > <?php echo e(__('Login')); ?></button>
                </div>
                <div class="my-2 d-flex justify-content-center align-items-center">

                  <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link"class="auth-link text-black"  href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                 
                </div>
                
              </form>
            </div>
          
      </div></center>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
 

</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PSSPL Project\Chartr\resources\views/auth/login.blade.php ENDPATH**/ ?>
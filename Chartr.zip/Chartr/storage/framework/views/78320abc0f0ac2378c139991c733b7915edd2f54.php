<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="utf-8" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('/theme/default/assets/images/favicon.ico')); ?>">

        <!-- DataTables -->
        <link href="<?php echo e(asset('/theme/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/theme/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="<?php echo e(asset('/theme/default/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/theme/default/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/theme/default/assets/css/metisMenu.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/theme/plugins/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/theme/default/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
        
        <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('/theme/default/assets/a.css')); ?>" />

    </head>

    <body>
<!-- Left Sidenav -->
<div class="left-sidenav">
    <!-- LOGO -->
    <div class="brand">
        <a href="index.html" class="logo">
            <span>
                <img src="<?php echo e(asset('theme/default/assets/images/logo-sm.png')); ?>" alt="logo-small" class="logo-sm">
            </span>
            <span>
                <img src="<?php echo e(asset('theme/default/assets/images/logo.png')); ?>" alt="logo-large" class="logo-lg logo-light">
                <img src="<?php echo e(asset('theme/default/assets/images/logo-dark.png')); ?>" alt="logo-large" class="logo-lg logo-dark">
            </span>
        </a>
    </div>
    <!--end logo-->
    <div class="menu-content h-100" data-simplebar>
        <ul class="metismenu left-sidenav-menu">
            <li class="menu-label mt-0">Main</li>
            <li>
                <a href="<?php echo e(url('/')); ?>"> <i data-feather="home" class="align-self-center menu-icon"></i><span>Dashboard</span></a>
                <!-- <ul class="nav-second-level" aria-expanded="false">
                    <li class="nav-item"><a class="nav-link" href="index.html"><i class="ti-control-record"></i>Registration</a></li>
                    <li class="nav-item"><a class="nav-link" href="sales-index.html"><i class="ti-control-record"></i>Sales</a></li> 
                </ul> -->
            </li>

            <li>
                <a href="javascript: void(0);"><i data-feather="grid" class="align-self-center menu-icon"></i><span>Registration</span><span class="menu-arrow"><i class="mdi mdi-chevron-right"></i></span></a>
                <ul class="nav-second-level" aria-expanded="false">
                        
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/register-list-view')); ?>"><i class="ti-control-record"></i>List</a></li>
                </ul>
            </li>

            <hr class="hr-dashed hr-menu">          
        </ul>
    </div>
</div>
<!-- end left-sidenav--><?php /**PATH D:\PSSPL Project\Project-Registration\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
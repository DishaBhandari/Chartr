        
        <footer class="footer text-center text-sm-left">
            &copy; <?php echo e(date('Y')); ?> <a href=""><?php echo e(env('APP_NAME')); ?></a>
        </footer><!--end footer-->
    </div><!-- end page content -->
</div>

        <!-- jQuery  -->
        <script src="<?php echo e(asset('/theme/default/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/metismenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/feather.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/default/assets/js/moment.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/plugins/daterangepicker/daterangepicker.js')); ?>"></script>

        <script src="<?php echo e(asset('/theme/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/theme/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('/theme/default/assets/js/app.js')); ?>"></script>
        <script>
            $(document).ready(function () {
                $('.number_validation').on('keyup', function () {
                    if (/\D/g.test(this.value))
                    this.value = this.value.replace(/\D/g,'')
                });

                $('#state').on('change', function () {
                var idState = this.value;
                $("#city_id").html('');
                $.ajax({
                    url: "<?php echo e(url('fetch_cities')); ?>",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#city_id').html('<option value="">Select City</option>');
                        $.each(result, function (key, value) {
                            $("#city_id").append('<option value="' + value
                                .id + '">' + value.cities_name + '</option>');
                        });
                    }
                });
            });
            });
            $('#datatable').DataTable();       

        </script>
        
    </body>
</html><?php /**PATH D:\PSSPL Project\Project-Registration\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
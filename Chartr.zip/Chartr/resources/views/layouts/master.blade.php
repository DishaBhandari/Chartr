@include('layouts.sidebar')
@include('layouts.header')
@yield('dashboard')
@include('layouts.footer')
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ticket;

class RegisterUserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
   

    public function store(Request $req){
        
            Ticket::create($req->all());
            $ticket = Ticket::latest()->first();

            return view('admin.Ticket.ticket_view',compact('ticket'));
    }

    public function viewTicket(){
        $ticket = Ticket::latest()->first();
        return view('admin.Ticket.ticket_view',compact('ticket'));
    }


    
}
